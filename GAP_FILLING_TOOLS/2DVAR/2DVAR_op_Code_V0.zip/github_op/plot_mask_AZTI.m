% lecture et trac� du masque RAZ en KM

clear all; clc
gr=load('mask.dat','r'); [ny,nx]=size(gr);

xr=[81.4881; 3.8705];yr=[10.2840; 17.2832]; 


figure(1); clf;
ni=35; nj=25; dx=2.5;
lon0=-2-48/60; lat0=43+18/60; % pt de reference pour la grille en coord GEO
i=0; xdecal=1.0*0; ydecal=2.0*0; 
for y=0: dx: (ny-1)*dx % 20
    i=i+1;
    j=0;
    for x=0:dx : (nx-1)*dx %18
        j=j+1;
        xg(i,j)=x+xdecal;
        yg(i,j)=y+ydecal;
%         [xg(i,j), yg(i,j)]=km2lonlat(lon0,lat0,xg(i,j), yg(i,j) );
    end
end

yg=flipud(yg);  %% AS uniquement pour le trac� 
for i=1:ny
    for j=1:nx
        if gr(i,j)==0; plot(xg(i,j),yg(i,j),'.b','markersize',20); end % cote en bleu
        hold on;
        if gr(i,j)==1 | gr(i,j)==2; 
            plot(xg(i,j),yg(i,j),'.k','markersize',18); end
    end
end
hold on;
% add coastline & radars
load('coastline_f.mat'); loc=ncst(:,1);lac=ncst(:,2); clear ncst Area k;
[xc,yc]=lonlat2km(lon0,lat0,loc,lac); %xgkm=fliplr(xgkm)+0.0003;
co =0.4; plot(xc,yc,'.','MarkerSize',12,'color',[co co co]);
xlim([-2.5 90]); ylim([-2.5 90]); set(gca,'box','on','FontSize',14);
xlabel('km','FontSize',14);
plot(xr,yr,'.g','MarkerSize',18);


break
% ========= mask11 =========
gr11=load('mask11.dat','r');  co=0.7;
for i=1:ny
    for j=1:nx
        if gr11(i,j)==2; plot(xg(i,j),yg(i,j),'.','markersize',20,'color',[co co co]); end % 
        hold on;
    end
end


axis([ -3 20 0 22 ]); axis square;
set(gca,'box','on')


