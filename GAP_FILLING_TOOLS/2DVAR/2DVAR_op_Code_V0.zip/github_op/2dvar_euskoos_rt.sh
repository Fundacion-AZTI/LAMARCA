#!/bin/bash
#######################################################################
#set x=0
#set y=1
#while [$x -le $y]
#do
echo
cd /home/arubio/2DVAR/euskoos_op
echo
# execute the computation of 2Dvar in IBIZA
/usr/bin/matlab -nodisplay -r int_2dvar_azti_aru_op
echo "hecho"
#bye

