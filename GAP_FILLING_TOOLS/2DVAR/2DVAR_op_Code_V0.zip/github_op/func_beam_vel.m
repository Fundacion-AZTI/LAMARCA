%  DRAW radial velocity matrix in colorplot. Show spikes.  
%
clear all; clc; 
scale=100; %40; % arrow scale 

xlim=[-3-15/60 -1-15/60]; ylim=[43+15/60  44+45/60]; set(gca,'xlim',xlim,'ylim',ylim)  % in DEG
facteur_1=1; facteur_2=(111/80)*diff(ylim)/diff(xlim);
a=get(gca,'plotboxaspectratio');
set(gca,'plotboxaspectratio',[a(1) a(2)*facteur_2/facteur_1 a(3)]);

for ir=2:2 % 1,2,3  radars 

if ir==1; %================== first radar ==============================
da1=load('Data\RDLm_HIGE_2022_04_29_0800.ruv');
rxy=[-1.7957500; 43.3925667];    
end
if ir==2; %================== second radar ==============================
da1=load('Data\RDLm_MATX_2022_04_29_0800.ruv');
rxy=[-2.7523000; 43.4555667];    
end

xg1=da1(:,1); yg1=da1(:,2); 
ve1=-1*da1(:,16); fi1=90-da1(:,15); 
for k=1:length(fi1); if fi1(k)<=-148; fi1(k)=fi1(k)+360;end; end;
ra1=da1(:,14);
%!!! multiply by -1 to set along-beam vel positive (i.e. from the R seaward)    
% ur1=ve1.*cos(fi1*pi/180); vr1=ve1.*sin(fi1*pi/180); 
% ur1=ur1/scale; vr1=vr1/scale;
% u1=da1(:,3)/scale; v1=da1(:,4)/scale; 
A=[fi1 ra1 ve1]; B=sortrows(A,1);   %matrix A with vel and geometry

% Set Radar config for Radials draw 
if ir==1;      %================== 
%RangeStart: 1;%RangeEnd: 38;%RangeResolutionKMeters: 5.096700; %AngularResolution: 5 Deg 
di=5.0967: 5.0967: 38*5.0967; ny=length(di); % Option: mid-distance of each RangeCell
be=47:5:192; nx=length(be);  DUM(1:ny,1:nx)=NaN; V(1:ny+1,1:nx+1)=NaN; % bearing
end % first radar =============
if ir==2;      %================== 
%RangeStart: 1;%RangeEnd: 39;%RangeResolutionKMeters: 5.096700; %AngularResolution: 5 Deg 
di=5.0967: 5.0967: 39*5.0967; ny=length(di); % Option: mid-distance of each RangeCell
be=-8:5:167; nx=length(be);  DUM(1:ny,1:nx)=NaN; V(1:ny+1,1:nx+1)=NaN; % bearing
end % second radar =============
for k=1:length(fi1); 
  for i=1:ny
    for j=1:nx
    if single(be(j))==single(fi1(k)) && single(di(i))==single(ra1(k)); DUM(i,j)=ve1(k); 
%     if be(j)==fi1(k) && di(i)==ra1(k); DUM(i,j)=ve1(k); 
%     fprintf('%8.4f %8.4f %8.4f\n',fi1(k),ra1(k),ve1(k));
    end;    
    end
  end
end
V(1,2:nx+1)=be; V(2:ny+1,1)=di; V(2:ny+1,2:nx+1)=DUM;

figure(4); 
if ir==1; plot(xg1,yg1,'.b','MarkerSize',12); end; hold on;
if ir==2; plot(xg1,yg1,'.k','MarkerSize',12); end; hold on;
set(gca,'xlim',xlim,'ylim',ylim,'FontSize',14);


%  function: draw radial velocity map with pcolor
%==============================================================
figure(1); clf
%trac� du colorbar
            axes('position',[0.87 0.2 0.05 0.7])
            zcolor=linspace(-50,50,100);bcolor=[zcolor' zcolor'];
            pcolor([0 1],zcolor,bcolor);shading interp
            title('cm/s','FontSize',16)
            set(gca,'xticklabel',[])

%pcolor des composantes radiales
            axes('position',[0.1 0.2 0.7 0.7])
%         alphal=pi*(theta0+teta+90)/180.; % initial 
teta=be; theta0=0; x0=0; y0=x0; dist=di';
        alphal=pi*(theta0+teta)/180.;
        x=x0+dist*cos(alphal);
        y=y0+dist*sin(alphal); 
            pcolor(x,y,DUM);
            caxis([-50 50.0]);   
%             if i_sta==1; axis([-20 110 30 150]); end;
%             if i_sta==2; axis([-20 110 30 150]); end;
%              axis('equal'); 
            hold on;
%             text(x0,y0+5,num2str(i_sta)); %,'FontSize',16)
            plot(x0,y0,'k.','MarkerS',15)

            set(gca,'FontSize',12);
            xlabel('(km)','FontSize',12); ylabel('(km)');

break



load('Data\coastline_f.mat'); loc=ncst(:,1);lac=ncst(:,2); clear ncst Area k; co=0.4;
% %------- draw velocity sampled at ray-points
% ib=1;ie=length(u1); hq=quiver(xg1(ib:ie),yg1(ib:ie),u1(ib:ie),v1(ib:ie),0.,'k'); set(hq,'LineW',1.25);
% plot(rxy(1), rxy(2),'.g','MarkerS',26); 
% % add coastline
% co =0.4; plot(loc,lac,'.','MarkerSize',12,'color',[co co co]);
% set(gca,'box','on','FontS',14);
% xlabel('Longitude (deg W)','FontS',14); ylabel('Latitude (deg N)','FontS',14); 

% plot obs points for each radar
figure(4); clf;
if ir==1; plot(xg1,yg1,'.b','MarkerSize',12); end; hold on;
set(gca,'xlim',xlim,'ylim',ylim,'FontSize',14);
if ir==2; plot(xg1,yg1,'.r','MarkerSize',12); end;
plot(loc,lac,'.','MarkerSize',12,'color',[co co co]);
end  % loop radar station


% nk=length(vec); [usm,usm]=filt_gaussas(vec,vec,dt0,nk,Cu,niter); 



