% programme d'interpolation int_2dvar.m 
% entree: deux fichiers de donnees issus de traitement des donnees brutes CODAR AZTI 
% sortie: vecteurs vitesses interpolees, avec sortie jpeg, et numerique.

clear all;  fclose all; %clf;
% clc; 
run('/data/radar_hf/PROCESADO/REALTIME/HFR_Progs_monterrey/matlab/startup.m')
% Options
i_fig=1;        %sortie graphique des composantes radiales. 1: oui; 0: non
iopt=1;         %sortie des cartes numeriques (2.5 km)
i_fic=1;    	%0: traitement d'un couple de fichiers de radiales
                %1: serie de fichiers                
step_fic=1;     %step entre fichiers
disp(['step entre fichier: ' num2str(step_fic)])

% entree du fichier 1 (lecture dans le repertoire de la station 1)
dir='In';
% borramos ficheros previos
eval(['!rm ' dir '/' '*ruv*'])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Composantes radiales: lecture et formation des paires radar1-radar2.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Enregistrement dans out_RH1.dat et out_RM2.dat 
% Enregistrement des dates dans dates.txt

% entree du fichier de debut
% [file1,cdpath]=uigetfile([dir '\*182004*_EF1.cel']);
% [file1,cdpath]=uigetfile([dir '\2007236*_bre.coc']);  % EXTENTION .coc  changed in 5 locations

%[file1,cdpath]=uigetfile(['*.ruv']);  % EXTENTION .coc  changed in 5 locations
%%%% WE TRANFER THE DATA FROM THE FTP TO THE in_dir for the last 2 days
 data1=now-1;vdata1=datevec(data1);
 data2=now;vdata2=datevec(data2);
 data_dia1=datestr(data1,'dd');
 data_dia2=datestr(data2,'dd');
 data_mes1=datestr(data1,'mm');
 data_mes2=datestr(data2,'mm');
 data_year1=datestr(data1,'yyyy');
 data_year2=datestr(data2,'yyyy');
 data_i=datenum(vdata1(1),vdata1(2),vdata1(3),0,0,0):1/24:datenum(vdata2(1),vdata2(2),vdata2(3),0,0,0);
 for ihora=['00';'01';'02';'03';'04';'05';'06';'07';'08';...
         '09';'10';'11';'12';'13';'14';'15';'16';'17';...
         '18';'19';'20';'21';'22';'23']';
 
%%% TRANSFERS RADIAL DATA%%%%%%%%%%%%%%%%%%%%%%%%%
 eval(['!wget ftp://dmc:boyasWS@ftp2.azti.es/dmc_raw/RDLm_HIGE_' ...
     data_year1 '_' data_mes1 '_' data_dia1 '_' ihora' '00.ruv']);
 eval(['!wget ftp://dmc:boyasWS@ftp2.azti.es/dmc_raw/RDLm_HIGE_' ...
     data_year2 '_' data_mes2 '_' data_dia2 '_' ihora' '00.ruv']);
 eval(['!wget ftp://dmc:boyasWS@ftp2.azti.es/dmc_raw/RDLm_MATX_' ...
     data_year1 '_' data_mes1 '_' data_dia1 '_' ihora' '00.ruv']);
 eval(['!wget ftp://dmc:boyasWS@ftp2.azti.es/dmc_raw/RDLm_MATX_' ...
     data_year2 '_' data_mes2 '_' data_dia2 '_' ihora' '00.ruv']);

 end

eval(['!mv ' 'RDLm_*.ruv ' dir])

cdpath=[pwd '/In/'];
 
 
% %                                 RDLm_HIGE_2022_04_28_0000.ruv
% % entree du fichier de fin
% if i_fic==1
% %     [file2,cdpath]=uigetfile([dir '\*182004*_EF1.cel']);
%     [file2,cdpath]=uigetfile([ '*.ruv']);
% else
%     file2=file1;
% end
%%
% creation des fichiers texte tmp.txt listant tous les fichiers presents dans dir  
eval(['!dir ' cdpath '\RDLm_HIGE*_2*.ruv > RH1.txt'])
fid=fopen('RH1.txt','r'); a1=fscanf(fid,'%s'); fclose(fid);
%añado (a mejorar) para que se quede más tarde con todos los ficheros que
%hay en el directorio de entrada
file1=a1(34:62);file2=a1(end-28:end);
eval(['!dir ' cdpath '\RDLm_MATX*_2*.ruv > RM2.txt'])
fid=fopen('RM2.txt','r'); a2=fscanf(fid,'%s'); fclose(fid);
   
% noms des fichiers fic1,2(n,:) correspondants. Ici, les fichiers sont 
%du type 2005160HHMM_EF1(ES2).cel
n1=0; for i=1:62:length(a1) char=a1(i:i+61); n1=n1+1; fic1(n1,:)=char; end
n2=0; for i=1:62:length(a2) char=a2(i:i+61); n2=n2+1; fic2(n2,:)=char; end

% dates en jour julien des fichiers. La date 0 correspond e la 1ere date de ES1 (rd1) 
for i=1:n1  % radar 1
    char=fic1(i,44:58); an=str2num(char(1:4)); mo=str2num(char(6:7));dy=str2num(char(9:10));
%     julien=str2num(char(6:8));
    heure=str2num(char(12:13)); min=str2num(char(14:15));
    jul(i)=mo*0+dy+(heure+min/60)/24;
%     jul(i)=an/365+julien+(heure+min/60)/24;
end
j0=jul(1); jul1=jul-j0;

for i=1:n2  % radar2
    char=fic2(i,44:58); an=str2num(char(1:4)); mo=str2num(char(6:7));dy=str2num(char(9:10));
    heure=str2num(char(12:13)); min=str2num(char(14:15));
    jul(i)=mo*0+dy+(heure+min/60)/24;
end
jul2=jul-j0;  % AS ICI on peut soustraire j0=ju2(1);

% determination des rangs i1 et i2 correspondant e file1
k=0;
for i=1:n1
    if file1==fic1(i,34:62) i1=i; k=1; end
    if k~=0 k=k+1; end
    if file2==fic1(i,34:62) i2=i; break; end
end
nvac=k;

% Determination des paires de fichiers nam1 et nam2 correspondants aux radars
% 1 et 2 separes de moins de 16 minutes (radar2=radar1 +(<16 minutes);
int=num2str(12/60/24);   %AS    %intervalle de temps en minutes entre les stations
int=str2num(int);
n=0;
for i=i1:i2
    dif=jul2-jul1(i);
    a=find(dif>=0 & dif<int);
    if isempty(a)==0
        n=n+1;
        nam1(n,:)=fic1(i,:);
        nam2(n,:)=fic2(i,:);
        disp([nam1(n,:) ' ' nam2(n,:)])
    end
end
    
ik=0; % compteur de fichiers lus pour chaque station
fid_date=fopen('dates.txt','w'); % ouverture du ficheier contenant les dates des vac traitees

 % Balayage des fichiers avec le pas defini
 for i=1:step_fic:n
    
    % ouverture du fichier de donnees pour int_2dvar (renouvele a chaque vacation) 
    fio=fopen('out12.dat','w');    
    ik=ik+1;
    
    % Balayage des stations    
for i_sta=1:2 
        if i_sta==1; 
            nam='_bre'; disp('Station 1 HIGE ...');
            file=nam1(i,:);
        end
        if i_sta==2; 
            nam='_gar'; disp('Station 2 MATX ...'); 
            file=nam2(i,:);
        end

        %ecriture de la date si istation==1
        if i_sta==1 fprintf(fid_date,'%s\n',file(34:62)); end

%le fichier .ruv contient les courants et parametres de geometrie
% ne pas multiplier par -1! la convention - pos vel vers le radar (CODAR) 
        %nomfich=[cdpath file(1:end)];  % EXTENTION .coc  changed HERE         
        nomfich=[file(1:end)];  % EXTENTION .coc  changed HERE 
        da1=load(nomfich);
ve1=+1*da1(:,16);fi1=90-da1(:,15); ra1=da1(:,14);xg1=da1(:,1); yg1=da1(:,2); 
for k=1:length(fi1); if fi1(k)<=-148; fi1(k)=fi1(k)+360;end; end;
teta=fi1; dist=ra1; u=ve1; % noms variables communs pour les deux methodes 'i_fig' 

% defenir le pt de reference de la grille d'interpolation (en KM) et coor station radar (en KM) 
% % HIGE: -1.7957500; 43.3925667 (Master) x=81.4881; y=10.2840 km (Ref.: lon0=-2-48/60; lat0=43+18/60)
% % MATX: -2.7523000; 43.4555667 (Slave) x=3.8705; y=17.2832 en km
lon0=-3; lat0=43+18/60; % pt de reference en coord GEO
        x0=0; y0=0; theta0=0; % initialiser pt de reference pour la grille interp en km
        if i_sta==1; theta0=0; [x0 y0]=lonlat2km(lon0,lat0, -1.7957500,  43.3925667);
        else         theta0=0; [x0 y0]=lonlat2km(lon0,lat0, -2.7523000,  43.4555667);
        end
        
        if i_fig==0; % PAS de CARTE VIT RAD: generer le fich sortie directement e partir des fich entree .ruv 
        alphal=pi*(theta0+teta)/180.;
        x=x0+dist.*cos(alphal);  y=y0+dist.*sin(alphal); 
        si=-sin(alphal);cs=-cos(alphal);
           for ifi=1:length(teta);
           fprintf(fio,'%8.4f %8.4f %9.3f %9.3f %9.3f \n',... % enregistrer vitesse de la 
           si(ifi),cs(ifi),x(ifi),y(ifi),u(ifi) ); %vacation en cours
           end
        end  % (i_fig) fin d'ecriture out12.dat pour la station en cours (!)

% ----- sortie graphique des composantes radiales et ecriture out12.data partir d'une matrice ang - dist 
    if i_fig==1
            if i_sta==2
                axes('position',[0.2 0.52 0.50 0.42])  
%                 cutoff=0.0; u(sta2<=cutoff)=NaN; % tenir compte des statistiques (XX% cutoff)
                func_plot_radvel; 
                h=colorbar('vert'); set(h,'Position', [0.75 0.25 0.04 0.5 ]);
                eval(['print -djpeg CARTES_rad\' nomfich(end-23:end-6)]);    
            end
            if i_sta==1
            figure(1); clf;                 
                axes('position',[0.2 0.04 0.43 0.42]);
%                 cutoff=0.0; u(sta1<=cutoff)=NaN; % tenir compte des statistiques (XX% cutoff)
                func_plot_radvel; 
            end
% %    end %fin de graphique des comp. radiales
dist=VM(2:end,1); % distances en km
teta=VM(1,2:end); % azimuths
teta=teta'; theta0=0;
u=VM(2:end,2:end); clear VM;
        alphal=pi*(theta0+teta)/180.;
        x=x0+dist*cos(alphal');y=y0+dist*sin(alphal');
        si=-sin(alphal);cs=-cos(alphal);
        % % =============== generate OUT12.dat file cos,sin, x,y, u ===============
        for ifi=1:length(teta);
            for jdi=1:length(dist);
                if ( isnan(u(jdi,ifi))==1 ); u(jdi,ifi)=999; end
                fprintf(fio,'%8.4f %8.4f %9.3f %9.3f %9.3f \n',... % enregistrer vitesse de la 
                 si(ifi),cs(ifi),x(jdi,ifi),y(jdi,ifi),u(jdi,ifi) ); %vacation en cours
            end
        end
        clear DUM VM dis alphal
    end  % (i_fig==1) fin d'ecriture out12.dat pour la station en cours (!)
end  % fin de balayage des stations (boucle "i_sta")
    fclose(fio);  % fin d'ecriture dans le fichier out12.dat de la vacation en cours

% end % fin de balayage des vacations
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     num_it=1; num_it2=1;%%%% added lines to get the number of iterations
while num_it<100 & num_it2<20    %%%% added lines to get the number of iterations
    eval('!/home/arubio/2DVAR/euskoos_op/ges_new.exe > log.out')   %interpolation 2dvar 
     
     %%%% added lines to get the number of iterations
    fo=fopen('log.out','r');
    logout_scan=textscan(fo,'%s');
    num_it=str2num(cell2mat(logout_scan{1,1}(end,1)))
    clear logout_scan
    !rm log.out
         %%%% added lines to get the number of iterations
    num_it2=num_it2+1;     %%%% added lines to get the number of iterations
end     %%%% added lines to get the number of iterations

    
     %%%%
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %     er1=func_error_md;  er1=round(er1*100)/100; % interpolation error (relative) 
%     er1=0.0; fprintf(' md error = %4.2f    ',er1); 
%     % Date des plots et des fichiers enregistres
%     % Nota: la date est celle du radar maitre, c'est-e-dire HIIGE
    tmp=(nam1(i,44:58));
    date=[tmp(1:4) '-' tmp(6:7) '-' tmp(9:10) ' ' tmp(12:13) ':00'];
    s_date=datenum(str2num(tmp(1:4)),str2num(tmp(6:7)), str2num(tmp(9:10)), str2num(tmp(12:13)),0,0);
    %disp(date);    disp(datestr(s_date))
    func_save_vel_g
    tit=['2dVar 2.5 km  ', date];  
    disp(tit); disp(' ');
%     % trace de la carte 2.5 km
    figure(2); func_plot_vel_g; title(tit);
%     % enregistrement carte numerique dans CARTES_V et sortie jpeg 
    if iopt==1; dat=[tmp(1:4) tmp(6:7) tmp(9:10) tmp(12:13) '00'];
        eval(['print -dpng CARTES_V\' dat]);
    end
    
    DA(ik)=str2num(dat); % ER(ik)=er1; 
    U(:,:,ik)=ui(:,:); V(:,:,ik)=vi(:,:);% vitesses de toutes les vacations traitees
%     load rot_opt.dat; R(:,:,ik)=rot_opt(:,:)'; 
%     load div_opt.dat; D(:,:,ik)=div_opt(:,:)'; 
%     
end % fin de balayage des vacations

% save UVDA.mat U V DA
% % ER=ER'; DA=DA'; % int. error & date of the current map as written in Title 
% % save UVRD.mat  U V R D ER DA
fclose all;
exit
