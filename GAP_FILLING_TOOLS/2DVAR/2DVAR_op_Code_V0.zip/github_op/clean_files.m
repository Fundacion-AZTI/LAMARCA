close all; clear all; clc;

in_dir=['/home/arubio/2DVAR/In/'];
out_dir=['/home/arubio/2DVAR/In_Lohi'];
nfiles=length(in_dir);
files=dir([in_dir '*.ruv']);
%files_MATX=dir([in_dir 'RDL_MATX*.ruv']);


for nf=1: length(files)
   nom=files(nf).name;
   if nom(1:9) == ['RDLm_HIGE']
           for i=1:length(files)
            nom_2=files(i).name;
            
            if nom_2 == ['RDLm_MATX' nom(10:25) '.ruv']
                i
                %disp (['copiando ' nom ' en posicion ' num2str(nf) ' y ' nom ' en posicion ' num2str(i) ' a ' '/home/arubio/2DVAR/In_Lohi/'])
                copyfile (nom , out_dir)
                copyfile (nom_2 , out_dir)
            else
                
            end
        end
   else
   end
    
end
