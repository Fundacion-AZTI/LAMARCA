%lineas compilación nueva precisión

gfortran -c -fdefault-real-8 m1qn3.f
gfortran ass100_new.f90 m1qn3.o -ffpe-trap=invalid,overflow -fdefault-real-8 -o ges_new.exe



%lineas compilacion antiguas
gfortran -c m1qn3.f 
gfortran ass100_new.f90 m1qn3.o -o ges.exe

