%  DRAW radial velocities and remove spikes  
%
clear all; clc; 
scale=100; %40; % arrow scale 

for ir=1:1 % 1,2,3  radars 

if ir==1; %================== first radar ==============================
da1=load('Data\RDLm_HIGE_2022_04_29_0800.ruv');
rxy=[-1.7957500; 43.3925667];    
end
if ir==2; %================== second radar ==============================
da1=load('Data\RDLm_MATX_2022_04_29_0800.ruv');
rxy=[-2.7523000; 43.4555667];    
end
% if ir==3; %================== third radar ==============================
% da1=load('d:\Alex\Radar_progs\Max_ruv\low_n030_gap\RDLm_NPGS_2007_11_01_1400.ruv');
% rxy=[-122.98913; 38.04715];
% end
% column 17=Direction; 16=Vel('+' toward the HFR & '-' along the beam); 15=Bearing (ccw from N ); 13=Y; 12=X; 2=LON; =LAT; 

xg1=da1(:,1); yg1=da1(:,2); 
ve1=-1*da1(:,16); fi1=90-da1(:,15); A=[fi1 ve1]; %!!! multiply by -1 to set along-beam orientation positive     
% ur1=ve1.*cos(fi1*pi/180); vr1=ve1.*sin(fi1*pi/180); 
% ur1=ur1/scale; vr1=vr1/scale;
u1=da1(:,3)/scale; v1=da1(:,4)/scale; 
qu1=da1(:,4);qu2=da1(:,5); % spatial & tem quality indicators
u1(qu1>100)=NaN; u1(qu2>100)=NaN; 
s=sum(isnan(u1)==1);

load('Data\coastline_f.mat'); loc=ncst(:,1);lac=ncst(:,2); clear ncst Area k; co=0.4;
% %------- draw velocity sampled at ray-points
% ib=1;ie=length(u1); hq=quiver(xg1(ib:ie),yg1(ib:ie),u1(ib:ie),v1(ib:ie),0.,'k'); set(hq,'LineW',1.25);
% plot(rxy(1), rxy(2),'.g','MarkerS',26); 
% % add coastline
% co =0.4; plot(loc,lac,'.','MarkerSize',12,'color',[co co co]);
% set(gca,'box','on','FontS',14);
% xlabel('Longitude (deg W)','FontS',14); ylabel('Latitude (deg N)','FontS',14); 

% plot obs points for each radar
figure(4); clf;
xlim=[-3 -1-15/60]; ylim=[43+15/60  44+30/60]; set(gca,'xlim',xlim,'ylim',ylim)  % in DEG
facteur_1=1; facteur_2=(111/80)*diff(ylim)/diff(xlim);
a=get(gca,'plotboxaspectratio');
set(gca,'plotboxaspectratio',[a(1) a(2)*facteur_2/facteur_1 a(3)]);
if ir==1; plot(xg1,yg1,'.b','MarkerSize',12); end; hold on;
set(gca,'xlim',xlim,'ylim',ylim,'FontSize',14);
if ir==2; plot(xg1,yg1,'.r','MarkerSize',12); end;
plot(loc,lac,'.','MarkerSize',12,'color',[co co co]);
end  % loop radar station

% params for performing smoothing 
    nsm=2; dt0=1; Cu=0.09; niter=2*nsm^2;  
% draw along beam vel (A=[90�-beam, vel*(-1)])
figure(5); clf;
B=sortrows(A,1);  
be=-268:5:-158; be=[be -48 -28 -23 -18 -13 12 17 22 27 37 42:5:87]; 
for i=1:2 %length(be)  % nb of beams used in comparison 
    val=be(i); dif=B(:,1)-val; dum=find(dif==0); 
    if i==1; ind=dum(end); vec=B(1:ind,2); ind1=ind; 
    nk1=length(vec); [usm,usm]=filt_gaussas(vec,vec,dt0,nk1,Cu,niter); S(:,i)=usm; V(:,i)=vec;
            plot(vec,'.-k'); hold on; plot(usm,'-g','LineW',2.5);
    else
    ind=dum(end); vec=B(ind1+1:ind,2); ind1=ind;
    nk=length(vec); [usm,usm]=filt_gaussas(vec,vec,dt0,nk,Cu,niter); S(1:nk1,i)=usm(1:nk1);
    V(1:nk1,i)=vec(1:nk1); % nk1 is the length limit  
            plot(vec,'.-b'); hold on;  plot(usm,'--g','LineW',1.5);
    end; %clear dif dum;
end
set(gca,'FontSize',14); xlabel('cell nb','FontSize',14);ylabel('Rad vel, cm/s','FontSize',14);

R=range(S,2); % range of variation of the smoothed vel should be > 5 cm/s always
R(R<5)=3;

plot(R,'-r');line([0 nk1],[0 0],'color','r'); % range of variation of the smoothed vel
for j=1:2
    for i=1:nk1
if S(i,j)-V(i,j)>R(i)*1.5; V(i,j)=NaN; end;
    end
end

% nk=length(vec); [usm,usm]=filt_gaussas(vec,vec,dt0,nk,Cu,niter); 



