% function filt to make Gaussian smoothing 
function [vmx,vmy]=filt_gaussas(vx,vy,dt0,nt,Cu,niter);

for kk=1:niter
    for k=2:nt-1
       vmx(k)=vx(k)+Cu*(vx(k-1)-2*vx(k)+vx(k+1))/dt0^2;
       vmy(k)=vy(k)+Cu*(vy(k-1)-2*vy(k)+vy(k+1))/dt0^2;
    end
       vmx(1)=vx(1); vmx(nt)=vx(nt);
       vmy(1)=vy(1); vmy(nt)=vy(nt);
%       vmx(1)=0.5*(vmx(2)+vx(1)); vmx(nt)=0.5*(vmx(nt-1)+vx(nt));
%       vmy(1)=0.5*(vmy(2)+vy(1)); vmy(nt)=0.5*(vmy(nt-1)+vy(nt));
       vx=vmx; vy=vmy;
end    
vmx=vmx'; vmy=vmy'; 

% SUBROUTINE FILT(VX,VY,dt0,nt,Cu,niter)
%       REAL*8 VX(nt),VY(nt),vmx(nt),vmy(nt),dt(nt)
%       DO KK=1,NITER  
%        do k=2,nt-1
%        vmx(k)=vx(k)+Cu*(vx(k-1)-2*vx(k)+vx(k+1))/dt0**2
%        vmy(k)=vy(k)+Cu*(vy(k-1)-2*vy(k)+vy(k+1))/dt0**2
%        enddo
%        vmx(1)=vmx(2); vmx(nt)=vmx(nt-1)
%        vmy(1)=vmy(2); vmy(nt)=vmy(nt-1)
%        vx=vmx; vy=vmy
%       ENDDO
%       RETURN