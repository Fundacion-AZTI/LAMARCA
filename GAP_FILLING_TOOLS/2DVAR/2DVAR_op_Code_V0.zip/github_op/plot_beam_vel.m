%  DRAW radial velocities and prepare
%  output file (out12.dat) for 2dVar interpolation 
%
clear all; clc; 
scale=100; %40; % arrow scale 
    fio=fopen('out12.dat','w'); % output file   

for ir=1:2 % 3 Data of THREE radars 

if ir==1; %================== first radar ==============================
da1=load('Data\RDLm_HIGE_2022_04_28_0900.ruv');
rxy=[-1.7957500; 43.3925667];    
end
if ir==2; %================== second radar ==============================
da1=load('Data\RDLm_MATX_2022_04_28_0900.ruv');
rxy=[-2.7523000; 43.4555667];    
end
if ir==3; %================== third radar ==============================
da1=load('d:\Alex\Radar_progs\Max_ruv\low_n030_gap\RDLm_NPGS_2007_11_01_1400.ruv');
rxy=[-122.98913; 38.04715];
end
% column 17=Direction; 16=Vel('+' toward the HFR & '-' along the beam); 15=Bearing (ccw from N ); 13=Y; 12=X; 2=LON; =LAT; 

xg1=da1(:,1); yg1=da1(:,2); 
ve1=-1*da1(:,16); fi1=90-da1(:,15); A=[fi1 ve1]; %!!! multiply by -1 to set along-beam orientation positive     
% ur1=ve1.*cos(fi1*pi/180); vr1=ve1.*sin(fi1*pi/180); 
% ur1=ur1/scale; vr1=vr1/scale;
u1=da1(:,3)/scale; v1=da1(:,4)/scale; 
qu1=da1(:,4);qu2=da1(:,5); % spatial & tem quality indicators
u1(qu1>100)=NaN; u1(qu2>100)=NaN; 
s=sum(isnan(u1)==1);


figure(ir); clf; % ------- set FIG aspect ratio ----------
xlim=[-3 -1-15/60]; ylim=[43+15/60  44+30/60]; set(gca,'xlim',xlim,'ylim',ylim)  % in DEG
facteur_1=1; facteur_2=(111/80)*diff(ylim)/diff(xlim);
a=get(gca,'plotboxaspectratio');
set(gca,'plotboxaspectratio',[a(1) a(2)*facteur_2/facteur_1 a(3)]);

hold on
%------- draw velocity sampled at ray-points
ib=1;ie=length(u1); hq=quiver(xg1(ib:ie),yg1(ib:ie),u1(ib:ie),v1(ib:ie),0.,'k'); set(hq,'LineW',1.25);
plot(rxy(1), rxy(2),'.g','MarkerS',26); 

% add coastline
load('coastline_f.mat'); loc=ncst(:,1);lac=ncst(:,2); clear ncst Area k;
co =0.4; plot(loc,lac,'.','MarkerSize',12,'color',[co co co]);

set(gca,'box','on','FontS',14);
xlabel('Longitude (deg W)','FontS',14); ylabel('Latitude (deg N)','FontS',14); 
% plot obs points for each radar
figure(4); 
if ir==1; plot(xg1,yg1,'.b','MarkerSize',12); end; hold on;
set(gca,'xlim',xlim,'ylim',ylim,'FontSize',14);
if ir==2; plot(xg1,yg1,'.r','MarkerSize',12); end;
plot(loc,lac,'.','MarkerSize',12,'color',[co co co]);
end  % loop radar station

% scale in km
lon0=-3.5; lat0=43.0;
x1=-1-30/60; x2=-1-22.64/60; y1=43+25/60;
[xikm,yikm]=lonlat2km(lon0,lat0,x1,y1); [xkm,ykm]=lonlat2km(lon0,lat0,x2,y1);
di=sqrt( (xikm-xkm).^2 + (yikm-ykm).^2 );
hl=line([x1 x2],[y1 y1]); set(hl,'LineWidth',2,'color','k'); text(x1+0.02, y1+.045,'10 km','FontSize',16,'Color','k')
ddx=abs(x2-x1);plot([x1 x1+ddx/4 x1+ddx/2 x1+ddx*3/4 x2 ],[y1 y1 y1 y1 y1],'.k','MarkerSize',12);
% % m_plot(x1, y1+.01,'10 km','FontSize',16,'Color','b')
% m_plot([x1 x2], [y1,y1],'.b','MarkerSize',16); m_plot(x1+(x2-x1)/5, y1,'.b','MarkerSize',16);
% m_text(x1+0.004, y1-.015,'2','FontSize',16,'Color','b')

% interpolation grid (2.5 km)
xg0=-2-48/60; yg0=43+18/60; lx=35; ly=25; dx=ddx/4; dy=dx; % set grid size HERE
for i=1:ly
    yg(i)=yg0+(i-1)*dy; 
    for j=1:lx; xg(j)=xg0+ (j-1)*dx; end;
end
[X,Y]=meshgrid(xg,yg);
plot(X,Y,'.k');

% draw along beam vel (A=[90�-beam, vel*(-1)])
figure(5); clf;
B=sortrows(A,1);
be=-268:5:-158; be=[be -48 -28 -23 -18 -13 12 17 22 27 37 42:5:87]; 
for i=1:3 %length(be)
    val=be(i); dif=B(:,1)-val; dum=find(dif==0); 
    if i==1; ind=dum(end); vec=B(1:ind,2); ind1=ind; 
            plot(vec,'.-k'); hold on;
    else
    ind=dum(end); vec=B(ind1+1:ind,2); ind1=ind;
    
    plot(vec,'.-b'); hold on;
    end; %clear dif dum;
end
set(gca,'FontSize',14);
xlabel('cell nb','FontSize',14);ylabel('Rad vel, cm/s','FontSize',14);

break

% % prepare Output File for interpolation ============================
% % coord in km, sin, cos, vel write to file 
X0= -123.6347; Y0=37.8644; % =>  min(xg); min(yg); left lower corner will have coord (0,0)
[x,y]=lonlat2km(X0,Y0,xg1,yg1); %xgkm=fliplr(xgkm)+0.0003;
[rx,ry]=lonlat2km(X0,Y0,rxy(1),rxy(2)); 
        % % =============== generate OUT12.dat file sin,cos, x,y, u ===============
        si=+sin(fi1*pi/180);cs=+cos(fi1*pi/180);  % vel set '+' along the beam (cf line 23). No need to multiply by -1 si,cs
        for i=1:length(xg1);
%                 if ( isnan(u(jdi,ifi))==1 ); u(jdi,ifi)=999; end
                fprintf(fio,'%8.4f%8.4f%8.3f%8.3f%9.4f \n',... % enregistrer vitesse de la 
                 si(i ),cs(i ),x( i),y( i),ve1( i) ); %vacation en cours
        end   

figure(9); clf; % ----------- verify Velocity field in KM (grid) coordinates ------------
quiver( x,y,ur1,vr1,2., 'b'); hold on;
plot(rx, ry,'.k','MarkerS',26); 
set(gca,'box','on','FontS',14,'xlim',[0 64],'ylim',[0 80]);
xlabel('km','FontS',14,'FontS',14); 
[bx,by]=lonlat2km(X0,Y0,bnd(:,1),bnd(:,2)); 
plot(bx, by,'color',[co co co],'LineW',2); 

% end  % loop radar station

fclose(fio);  % end of writing the radials into file out12.dat; close the file 


