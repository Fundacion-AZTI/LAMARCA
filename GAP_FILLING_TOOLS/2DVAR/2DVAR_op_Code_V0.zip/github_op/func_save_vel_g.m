%  function (arubio): save a *.mat y *.nc with the resulting current field in GEO coord system
%==============================================================
% figure(4); clf;

lon0=-3; lat0=43+18/60; % if function is called alone 
dx=2.5; lx=55; ly=35; xspan=(lx-1)*dx; yspan=(ly-1)*dx; % <-- grid 
sc=1.; void=999.;
[X,Y]=meshgrid([0:dx:(lx-1)*dx],[0:dx:(ly-1)*dx]); % <-- grid in KM
X=X+0.0; Y=Y+0.0; % with real (not the 1st grid point) origin
[XG,YG]=km2lonlat(lon0,lat0,X,Y); % <-- grid in deg

%-------------- interpolated velocity --------------------------
load mask11.dat; msc=mask11; msc(msc~=1)=nan;
load u_opt.dat; load v_opt.dat;
ui=u_opt'*sc.*flipud(msc); vi=v_opt'*sc.*flipud(msc);
%X=X.*flipud(msc); Y=Y.*flipud(msc); % masquer les pts de grille sans vitesses
             
out_name=[ 'HFR-EUSKOOS-2DVAR_' datestr(s_date,'YYYY_mm_DD_hh') '00.mat'];
%cd Out
save(out_name, 'XG', 'YG', 'ui', 'vi', 's_date'); 
%cd ..  %ojo con el cambio de folders, es muy cutre pero no he conseguido de otra manera


%% save a *.nc with the rsulting current field in GEO coord system%%%%%%%%

out_name_nc=[ 'HFR-EUSKOOS-2DVAR_' datestr(s_date,'YYYY_mm_DD_hh') '00.nc'];

%REFERENCIAMOS EL TIEMPO A DIAS DESDE 1950-01-01 00:00:00
t_ini=datenum('1950-01-01 00:00 00','yyyy-mm-dd HH:MM ss'); time=datenum(s_date)-t_ini;

%Definimos variables
TIME=time; longitude=XG; latitude=YG; EWCT(1,1:size(ui,1), 1:size(ui,2))=ui/100; NSCT(1,1:size(ui,1), 1:size(ui,2))=vi/100;

% To create the *.nc:
%elem_P1=1:size(TIME,1);
% Definimos variables y sus atributos: 
    % Convertimos por defecto los netcdfs a formato NETCDF4-classic model:
    oldFormat = netcdf.setDefaultFormat('NC_FORMAT_NETCDF4_CLASSIC');
    
    % Time: TIME
    nccreate([out_name_nc],'TIME','Dimensions',{'TIME',size(time,1)},'Datatype','double')
    ncwriteatt([out_name_nc],'TIME','units','days since 1950-01-01T00:00:00Z')
    ncwriteatt([out_name_nc],'TIME','long_name','Time')
    ncwriteatt([out_name_nc],'TIME','standard_name','time')
    ncwrite([out_name_nc],'TIME',time)
    
      % LON:
    nccreate([out_name_nc],'LONGITUDE','Dimensions',{'Longitude',size(longitude,2)},'Datatype','single')
    ncwriteatt([out_name_nc],'LONGITUDE','units','degree_east')
    ncwriteatt([out_name_nc],'LONGITUDE','long_name','Longitude of each location')
    ncwriteatt([out_name_nc],'LONGITUDE','standard_name','longitude')
    ncwrite([out_name_nc],'LONGITUDE',longitude(1,:),1)
  
    % LAT:
    nccreate([out_name_nc],'LATITUDE','Dimensions',{'Latitude',size(longitude,1)},'Datatype','single')
    ncwriteatt([out_name_nc],'LATITUDE','units','degree_north')
    ncwriteatt([out_name_nc],'LATITUDE','long_name','Latitude of each location')
    ncwriteatt([out_name_nc],'LATITUDE','standard_name','latitude')
    ncwrite([out_name_nc],'LATITUDE',latitude(:,1),1)

    
    % U: EWCT
    nccreate([out_name_nc],'EWCT','Dimensions',{'Longitude',size(longitude,2),'Latitude',size(longitude,1),'TIME',size(time,1)},'Datatype','single') %creamos variable y dimensiones
    ncwriteatt([out_name_nc],'EWCT','units','m s-1') %definimos atributos
    ncwriteatt([out_name_nc],'EWCT','long_name','West-east current component') %definimos atributos
    ncwriteatt([out_name_nc],'EWCT','standard_name','eastward_sea_water_velocity') %definimos atributos
    ncwrite([out_name_nc],'EWCT',permute(EWCT,[3 2 1])) %rellenamos variable con valores
    
    % V:NSCT
    nccreate([out_name_nc],'NSCT','Dimensions',{'Longitude',size(longitude,2),'Latitude',size(longitude,1),'TIME',size(time,1)},'Datatype','single') %creamos variable y dimensiones
    ncwriteatt([out_name_nc],'NSCT','units','m s-1') %definimos atributos
    ncwriteatt([out_name_nc],'NSCT','long_name','North-south current component') %definimos atributos
    ncwriteatt([out_name_nc],'NSCT','standard_name','northward_sea_water_velocity') %definimos atributos
    ncwrite([out_name_nc],'NSCT',permute(NSCT,[3 2 1 ])) %rellenamos variable con valores
    
  
  % Definimos atributos globales:
    ncwriteatt([out_name_nc],'/','acknowledgment','These data were processed by ULCO & AZTI and made freely available');
    ncwriteatt([out_name_nc],'/','area','South-Eastern Bay of Biscay');
    ncwriteatt([out_name_nc],'/','cdm_data_type','Grid');
    ncwriteatt([out_name_nc],'/','citation','These data were processed by ULCO & AZTI and made freely available');
    ncwriteatt([out_name_nc],'/','comment','Gap-filled 2DVAR surface currents');
    ncwriteatt([out_name_nc],'/','contact_email','lsolabarrieta@azti.es, arubio@azti.es, alexei.sentchev@univ-littoral.fr, sloane.bertin@univ-littoral.fr');
    ncwriteatt([out_name_nc],'/','contact_name','Lohitzune Solabarrieta, Anna Rubio, Alexei Sentchev, Sloane Bertin');
    ncwriteatt([out_name_nc],'/','conventions','');
    ncwriteatt([out_name_nc],'/','creator_email','lsolabarrieta@azti.es, arubio@azti.es, alexei.sentchev@univ-littoral.fr, sloane.bertin@univ-littoral.fr');
    ncwriteatt([out_name_nc],'/','creator_name','Lohitzune Solabarrieta, Anna Rubio, Alexei Sentchev, Sloane Bertin');
    ncwriteatt([out_name_nc],'/','creator_type','Foundation');
    ncwriteatt([out_name_nc],'/','creator_url','https://www.azti.es/, https://www.univ-littoral.fr/');
    ncwriteatt([out_name_nc],'/','data_assembly_center','AZTI');
    ncwriteatt([out_name_nc],'/','data_language','eng');
    ncwriteatt([out_name_nc],'/','data_mode','D');
    ncwriteatt([out_name_nc],'/','data_type','Gap-fille surface currents from HFR-EUSKOOS');
    ncwriteatt([out_name_nc],'/','date_update',datestr(max((datenum(time))),'yyyy-mm-dd HH:MM'));
    ncwriteatt([out_name_nc],'/','distribution_statement','These data are public and free of charge. User assumes all risk for use of data. User must display citation in any publication or product using data. User must contact PI prior to any commercial use of data');
    ncwriteatt([out_name_nc],'/','DOI','');
    ncwriteatt([out_name_nc],'/','format_version','1.4');
    ncwriteatt([out_name_nc],'/','geospatial_lat_max',max(max(latitude)));
    ncwriteatt([out_name_nc],'/','geospatial_lat_min','-1.336274550579877');
    ncwriteatt([out_name_nc],'/','geospatial_lat_units','degrees_north');
    ncwriteatt([out_name_nc],'/','geospatial_lon_max',max(max(longitude)));
    ncwriteatt([out_name_nc],'/','geospatial_lon_min','43.3');
    ncwriteatt([out_name_nc],'/','geospatial_lon_units','degrees_east');
    ncwriteatt([out_name_nc],'/','geospatial_vertical_max','-1');
    ncwriteatt([out_name_nc],'/','geospatial_vertical_min','-1');
    ncwriteatt([out_name_nc],'/','geospatial_vertical_units','m');
    %ncwriteatt([out_name_nc],'/','history',[datestr(min((datenum(time2))),'yyyy-mm-dd HH:MM'),' - ',datestr(max((datenum(time2))),'yyyy-mm-dd HH:MM'),' data collected. ',datestr(now,'yyyy-mm-dd HH:MM'),' netCDF file created using Matlab software']);
    ncwriteatt([out_name_nc],'/','infoUrl','https://www.azti.es/, https://www.univ-littoral.fr/');
    ncwriteatt([out_name_nc],'/','institution','AZTI (Spain)');
    ncwriteatt([out_name_nc],'/','institution_edmo_code','1623');
    ncwriteatt([out_name_nc],'/','institution_references','AZTI');
    ncwriteatt([out_name_nc],'/','keywords','OCEAN CURRENTS');
    ncwriteatt([out_name_nc],'/','keywords_vocabulary','GCMD Science Keywords');
    ncwriteatt([out_name_nc],'/','last_update',datestr(now,'yyyy-mm-dd HH:MM'));
    ncwriteatt([out_name_nc],'/','license','this dataset is licensed under a Creative Commons Attribution 4.0 International License. You should have received a copy of the license along with this work. If not, see http://creativecommons.org/licenses/by/4.0/');
    ncwriteatt([out_name_nc],'/','metadata_language','eng');
    ncwriteatt([out_name_nc],'/','naming_authority','AZTI');
    ncwriteatt([out_name_nc],'/','NetCDF_format','netcdf4_classic');
    ncwriteatt([out_name_nc],'/','NetCDF_version','netCDF-4 classic model');
    ncwriteatt([out_name_nc],'/','pi_name','');
    ncwriteatt([out_name_nc],'/','platform_code','');
    ncwriteatt([out_name_nc],'/','platform_name','');
    ncwriteatt([out_name_nc],'/','publisher_email','lsolabarrieta@azti.es, arubio@azti.es');
    ncwriteatt([out_name_nc],'/','publisher_name','Lohitzune Solabarrieta, Anna Rubio');
    ncwriteatt([out_name_nc],'/','publisher_type','Institution');
    ncwriteatt([out_name_nc],'/','publisher_url','www.azti.es');
    ncwriteatt([out_name_nc],'/','qc_manual','');
    ncwriteatt([out_name_nc],'/','references','2DVAR method is described in M. Yaremchuk, A. Sentchev, 2009. Mapping radar-derived sea surface currents with a variational method. Continent. Shelf Res., 29 (14) (2009), pp. 1711-1722, 10.1016/j.csr.2009.05.016; Please use the contact_email for more information on the parameter’s settings and the accuracy of the distributed datasets ');
    ncwriteatt([out_name_nc],'/','Standard_name_vocabulary','NetCDF Climate and Forecast Metadata Convention Standard Name Table Version 1.6; and https://www.seadatanet.org/Standards/Common-Vocabularies. ISO 19115, related to the geographical information');
    ncwriteatt([out_name_nc],'/','summary','2DVAR gap-filled currents derived from HFR-EUSKOOS. This dataset has been produced in the framework of the research project LAMARCA - LAgrangian transport of MARrIne litter and microplastics from modeling, analysis and observations in CoAstal waters (Grant PID2021-123352OB-C33 funded by MCIN/AEI/10.13039/501100011033 and by ERDF A way of making Europe), in a collaboration between ULCO & AZTI. Please visit lamarca-project.eu for more information');
    %ncwriteatt([out_name_nc],'/','time_coverage_end',datestr(max(datenum(time)),'yyyy-mm-dd HH:MM'));
    %ncwriteatt([out_name_nc],'/','time_coverage_resolution','1 hour');
    %ncwriteatt([out_name_nc],'/','time_coverage_start',datestr(min(datenum(time)),'yyyy-mm-dd HH:MM'));
    ncwriteatt([out_name_nc],'/','title','Gap-filled suface currents in the south-eastern Bay of Biscay by AZTI');
    ncwriteatt([out_name_nc],'/','update_interval','void');
    ncwriteatt([out_name_nc],'/','wmo_inst_type','');
    ncwriteatt([out_name_nc],'/','wmo_platform_code',''); 

    
%cd ..  %ojo con el cambio de folders, es muy cutre pero no he conseguido de otra manera
eval(['!cp ' out_name_nc ' /media/op_data/RADAR_2DVAR'])
eval(['!mv ' out_name_nc ' Out'])
eval(['!mv ' out_name ' Out'])

    
