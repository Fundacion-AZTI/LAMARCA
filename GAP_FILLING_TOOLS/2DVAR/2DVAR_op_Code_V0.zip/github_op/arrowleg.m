function h = arrowleg(quadrant,magnitude,units,scaleFactor,ArrowStyle)

% arrowleg draw a vector (using arrowplot) on the current (active) plot.
% INPUTS:
%         QUADRANT - the location where the legend is drawn.  Valid 
%         locations are:  UL (upper left), UR (upper right), LL (lower
%         left), LR (lower right), and CN (center).
%         
%         MAGNITUDE - is a number, not a string of the magnitude of the
%         vector to place in the legend.
%
%         UNITS - the units to place on the magnitude, such as m/s.
%         This arguement is a string.
% 
%         SCALEFACTOR - the scaling factor for arrowplot.  USE THE 
%         SAME SCALE FACTOR AS WAS USED TO MAKE THE PLOT VECTORS!!!
%
% The handle to the legend vector is passed back to the calling program.

% Very important note.  If the plot has an aspect ratio set, such
% as set for mercator scaling, then is is assumed that the vectors
% on the plot were scaled by multiplying the v component by the 
% data scaling factor of the aspectratio, ie. aspect(2)*v.  So since
% this legend creates a scale vector in the u component only, the
% aspectratio doesn't need to be dealt with.

% Mike Cook - NPS Oceanography Dept., 24JUN98.

if nargin < 5
   ArrowStyle = '-r';
end

% Hardwired values:  inPercent = how far in from the axes
%                    sepPercent = how far between the legend vector and 
%                                 labelling text.
inPercent = 5/100;
sepPercent = 1/100;

pos = axis;  %pos(1)=xmin, pos(2)=xmax, pos(3)=ymin, pos(4)=ymax
Xdist = abs(pos(2) - pos(1));
Ydist = abs(pos(4) - pos(3));

magLabel = magnitude;

if (strcmp(upper(quadrant),'UL'))
   XarrowLoc = pos(1) + (Xdist * inPercent);
   YarrowLoc = pos(4) - (Ydist * inPercent);
   XtextLoc = pos(1) + (Xdist * inPercent);
   YtextLoc = pos(4) - (Ydist * (inPercent+sepPercent));
   horizAlign = 'left';
   vertAlign = 'top';
elseif (strcmp(upper(quadrant),'LL'))
   XarrowLoc = pos(1) + (Xdist * inPercent);
   YarrowLoc = pos(3) + (Ydist * inPercent);
   XtextLoc = pos(1) + (Xdist * inPercent);
   YtextLoc = pos(3) + (Ydist * (inPercent+sepPercent));
   horizAlign = 'left';
   vertAlign = 'bottom';
elseif (strcmp(upper(quadrant),'UR'))
   XarrowLoc = pos(2) - (Xdist * inPercent);
   YarrowLoc = pos(4) - (Ydist * inPercent);
   XtextLoc = pos(2) - (Xdist * inPercent);
   YtextLoc = pos(4) - (Ydist * (inPercent+sepPercent));
   magnitude = -magnitude;
   horizAlign = 'right';
   vertAlign = 'top';
elseif (strcmp(upper(quadrant),'LR'))
   XarrowLoc = pos(2) - (Xdist * inPercent);
   YarrowLoc = pos(3) + (Ydist * inPercent);
   XtextLoc = pos(2) - (Xdist * inPercent);
   YtextLoc = pos(3) + (Ydist * (inPercent+sepPercent));
   magnitude = -magnitude;
   horizAlign = 'right';
   vertAlign = 'bottom';
elseif (strcmp(upper(quadrant),'CN'))
   XarrowLoc = mean(pos(1:2));
   YarrowLoc = mean(pos(3:4));
   XtextLoc = XarrowLoc;
   YtextLoc = YarrowLoc - (Ydist * (sepPercent));
   horizAlign = 'center';
   vertAlign = 'top';
else
   error('Bad quadrant argument ... terminating')
end

%%keyboard

hold on
%% line(XarrowLoc,YarrowLoc,'color','r','linestyle','+');
h = arrowplot(XarrowLoc,YarrowLoc,magnitude,0,scaleFactor,ArrowStyle);
set(h,'clipping','off');
hold off
%% line(XtextLoc,YtextLoc,'color','g','linestyle','o');
text(XtextLoc,YtextLoc,sprintf('%g %s',magLabel,units), ...
    'horizontalAlignment',horizAlign,'verticalAlignment',vertAlign, ...
    'fontweight','bold','Color','k','FontSize',13);

% Set axis back to original limits
axis(pos);
