%  function: draw a vector map in GEO coord system
%==============================================================
% figure(4); clf;

lon0=-3; lat0=43+18/60; % if function is called alone 
dx=2.5; lx=55; ly=35; xspan=(lx-1)*dx; yspan=(ly-1)*dx; % <-- grid 
sc=1.; void=999.;
[X,Y]=meshgrid([0:dx:(lx-1)*dx],[0:dx:(ly-1)*dx]); % <-- grid in KM
X=X+0.0; Y=Y+0.0; % with real (not the 1st grid point) origin
[XG,YG]=km2lonlat(lon0,lat0,X,Y); % <-- grid in deg
%-------------- cote & bathy ---------------
load lola; co=0.75; fill(lola(:,1),lola(:,2),[co co co])
% func_plot_bathy % function plot bathy
hold on;
%-------------- interpolated velocity --------------------------
load mask11.dat; msc=mask11; msc(msc~=1)=nan;
load u_opt.dat; load v_opt.dat;
ui=u_opt'*sc.*flipud(msc); vi=v_opt'*sc.*flipud(msc);
X=X.*flipud(msc); Y=Y.*flipud(msc); % masquer les pts de grille sans vitesses
%............... scaling arrow and vector plot ...................
inc=1; vscale=0.005; vscaleleg=10.0; % legend vec scale in cm/s
%............... vector plot in GEO coordinates ...................
xlim=[-3.1 -1.1]; ylim=[43.28 44.5001]; 
set(gca,'xlim',xlim,'ylim',ylim)  % in DEG
facteur_1=1; facteur_2=(111/80)*diff(ylim)/diff(xlim);
a=get(gca,'plotboxaspectratio');
set(gca,'plotboxaspectratio',[a(1) a(2)*facteur_2/facteur_1 a(3)]);

[c] = arrowplot(XG(1:inc:end,1:inc:end),YG(1:inc:end,1:inc:end),...
                   ui(1:inc:end,1:inc:end),vi(1:inc:end,1:inc:end),vscale,'k'); 
[h] = arrowleg('UL',vscaleleg,' cm/s',vscale,'k');
grid on;
set(gca,'box','on','FontSize',14);
line([xlim(1) xlim xlim(2)],  [ylim(2) ylim(1) ylim(1) ylim(2)],'color','k');
xlabel('Longitude','FontSize',14);ylabel('Latitude');
% title([nomfich(end-23:end-9) nomfich(end-8:end-9) ':00']);
% % %............... draw radar positions .......................
xr=[-1.7957500 -2.7523000]-0.002; yr=[43.3925667 43.4555667 ]-0.004; 
% plot(xr,yr,'sb','MarkerSize',6,'MarkerFaceColor','b');

