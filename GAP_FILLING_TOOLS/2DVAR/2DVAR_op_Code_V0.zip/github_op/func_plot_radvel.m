%  DRAW radial velocity matrix in colorplot from int_2dVar.   
%  Option: show & manage spikes.

A=[fi1 ra1 ve1]; B=sortrows(A,1);   %matrix A with vel and geometry
% Set Radar config for Radials draw 
if i_sta==1;      %================== 
%RangeStart: 1;%RangeEnd: 38;%RangeResolutionKMeters: 5.096700; %AngularResolution: 5 Deg 
di=5.0967: 5.0967: 38*5.0967; ny=length(di); % Option: mid-distance of each RangeCell
be=47:5:192; nx=length(be);  DUM(1:ny,1:nx)=NaN; VM(1:ny+1,1:nx+1)=NaN; % bearing
end % first radar =============
if i_sta==2;      %================== 
%RangeStart: 1;%RangeEnd: 39;%RangeResolutionKMeters: 5.096700; %AngularResolution: 5 Deg 
di=5.0967: 5.0967: 39*5.0967; ny=length(di); % Option: mid-distance of each RangeCell
be=-8:5:167; nx=length(be);  DUM(1:ny,1:nx)=NaN; VM(1:ny+1,1:nx+1)=NaN; % be: bearing
end % second radar =============
for k=1:length(fi1); 
  for ii=1:ny
    for jj=1:nx
    if single(be(jj))==single(fi1(k)) && single(di(ii))==single(ra1(k)); DUM(ii,jj)=ve1(k); end;    
    end
  end
end
VM(1,2:nx+1)=be; VM(2:ny+1,1)=di; VM(2:ny+1,2:nx+1)=DUM;  % 'VM' means velocity matrix 

%  draw radial velocity map with pcolor
%==============================================================
%trac� du colorbar
%             axes('position',[0.87 0.2 0.05 0.7])
            zcolor=linspace(-50,50,100);bcolor=[zcolor' zcolor'];
            pcolor([0 1],zcolor,bcolor);shading interp
            title('cm/s','FontSize',16)
            set(gca,'xticklabel',[])

%pcolor des composantes radiales
%             axes('position',[0.1 0.2 0.7 0.7])
teta=be; dist=di';
        alphal=pi*(theta0+teta)/180.;
        x=x0+dist*cos(alphal);
        y=y0+dist*sin(alphal); 
            pcolor(x,y,DUM);
            caxis([-50 50.0]);   
%              axis('equal'); 
            hold on;
            plot(x0,y0,'k.','MarkerS',15)
            set(gca,'FontSize',12);
            xlabel('(km)','FontSize',12); ylabel('(km)');



